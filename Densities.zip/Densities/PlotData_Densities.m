%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%                                                                     %%%
%%%   Paper: 3GPP-inspired Stochastic Geometry-based Mobility Model     %%%
%%%          for a Drone Cellular Network                               %%%
%%%   Authors: Morteza Banagar, Harpreet S. Dhillon                     %%%
%%%   Emails: mbanagar@vt.edu, hdhillon@vt.edu                          %%%
%%%                                                                     %%%
%%%   This code is used to generate the plot of Fig. 3, density of      %%%
%%%   the network of interferers for the second service model.          %%%
%%%                                                                     %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

ClipData1 = 4000;
load('.\Data\Model1_ConstantMove_Density_Simulation.mat')
load('.\Data\Model1_ConstantMove_Density_Theory.mat')
Density_Simulation_Model1 = Density_Simulation(:, 1 : ClipData1);
Density_Theory_Model1 = Density_Theory(:, 1 : ClipData1);
rVec1 = (1 : ClipData1).';
rVecDS = [100 : 200 : 1100, 1300 : 300 : 4000];
MarkerSize = 5;
LineWidth = 2;
figure(102)
s1 = gca;
hold on
plot(rVec1, Density_Theory_Model1(1, :), 'LineWidth', LineWidth, 'LineStyle', ':')
plot(rVec1, Density_Theory_Model1(2, :), 'LineWidth', LineWidth, 'LineStyle', '--')
plot(rVec1, Density_Theory_Model1(3, :), 'LineWidth', LineWidth, 'LineStyle', '-.')
plot(rVec1, Density_Theory_Model1(4, :), 'LineWidth', LineWidth, 'LineStyle', '-')
plot(rVecDS, Density_Simulation_Model1(:, rVecDS).', 'b', 'LineWidth', LineWidth, 'LineStyle', 'none', 'Marker', 'o', 'MarkerSize', MarkerSize)
xlabel('$u_{\mathbf x}$ (m)', 'FontName', 'Times', 'FontSize', 12, 'Interpreter', 'latex')
ylabel('$\lambda(u_{\mathbf x}, u_0, t)$', 'FontName', 'Times', 'FontSize', 12, 'Interpreter', 'latex')
set(s1, 'FontName', 'Times', 'FontSize', 12)
legend('Theory: $t = 20$ (s)', 'Theory: $t = 40$ (s)', 'Theory: $t = 50$ (s)', 'Theory: $t = 200$ (s)', 'Simulation')
legend1 = legend(s1);
set(legend1, 'Location', 'southeast', 'FontSize', 12, 'Interpreter', 'latex')
ylim([0, 1.05e-6])
hold off
grid on